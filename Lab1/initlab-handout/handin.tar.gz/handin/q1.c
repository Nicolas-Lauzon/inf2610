/*
 * Init Lab - q1.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------

// -------------------------------------------------
#include <stdio.h>
#include <unistd.h>
#include <string.h>


/*
 * Le programme doit imprimer sur la sortie standard le nombre d'arguments
 * qu'il a reçus et la liste de ces arguments, selon le format suivant:
 * 
 * Exécution en ligne de commande:
   $ ./q1 monargument1 2 monargument3
 * Sortie attendue:
   Program received 4 arguments:
   ./q1
   monargument1
   2
   monargument3
 * 
 * Attention:
 * - Chaque ligne doit être terminée par le caractère '\n' de fin de ligne
 * - Si le programme ne reçoit qu'un seul argument, la première ligne affichée
 *   par le programme doit être "Program received 1 argument:", sans 's' à la
 *   fin de "argument"
 */
int main(int argc, char* argv[]) {

    if (argc == 1){
      printf("Program received 1 argument:\n");
      printf("%s\n",argv[0]);
    }
    else{
      printf("Program received %d arguments:\n",argc);
      
      
      for (int size=0 ; argv[size] !=NULL ; size++){
        printf("%s\n",argv[size]);
        
      }
    }

    return 0;
}