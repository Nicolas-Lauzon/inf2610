/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_a5c51a2630e7f492"; //TODO

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_fa1aa73d7733878d"; //TODO

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "5dddc5bf6e71c86d001b7f59b8c587e68463df48b93bb91a8114777135682c72"; //TODO

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs"; //TODO

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "SLEEP_TIME"; //TODO

#endif
